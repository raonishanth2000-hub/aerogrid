"""AeroGrid Package Configuration."""
from __future__ import annotations

import os
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "ml" / "artifacts"
DATA_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except ImportError:
    pass

OPENAQ_API_KEY = os.getenv("OPENAQ_API_KEY", "").strip()
CENTER_LAT = float(os.getenv("CENTER_LAT", "28.6139"))
CENTER_LON = float(os.getenv("CENTER_LON", "77.2090"))
SEARCH_RADIUS_M = min(int(os.getenv("SEARCH_RADIUS_M", "25000")), 25000)
LOCAL_TIMEZONE = os.getenv("LOCAL_TIMEZONE", "Asia/Kolkata")

# AWS Configuration (Amazon S3 and Amazon SageMaker AI)
AWS_REGION = os.getenv("AWS_DEFAULT_REGION", os.getenv("AWS_REGION", "ap-south-1")).strip()
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", os.getenv("AWS_S3_BUCKET", "")).strip()
S3_PREFIX = os.getenv("S3_PREFIX", "aerogrid").strip()
SAGEMAKER_ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN", "").strip()

OPENAQ_BASE_URL = "https://api.openaq.org/v3"
OPEN_METEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
OPEN_METEO_AIR_QUALITY_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
OPEN_METEO_ELEVATION_URL = "https://api.open-meteo.com/v1/elevation"

WEATHER_VARIABLES = [
    "temperature_2m",
    "relative_humidity_2m",
    "wind_speed_10m",
    "wind_direction_10m",
    "pressure_msl",
]

from ml.features import FEATURE_COLUMNS
